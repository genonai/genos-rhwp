import { createHash } from "node:crypto";
import { existsSync, mkdirSync, statSync, writeFileSync } from "node:fs";
import { basename, resolve } from "node:path";

export function safeBasename(name, fallback) {
  const clean = basename(String(name || "")).replaceAll("\0", "");
  return clean && clean !== "." && clean !== ".." ? clean : fallback;
}

export function sha256(buffer) {
  return createHash("sha256").update(buffer).digest("hex");
}

export function outputFilename(inputPath, target, requestedName) {
  const inputName = basename(inputPath);
  const extension = inputName.lastIndexOf(".");
  const stem = extension > 0 ? inputName.slice(0, extension) : inputName;
  let name = requestedName ? safeBasename(requestedName, `${stem}-2020.${target}`) : `${stem}-2020.${target}`;
  if (!name.toLowerCase().endsWith(`.${target}`)) {
    name = `${name}.${target}`;
  }
  return name;
}

export function saveRemoteResult(toolResult, outputDir, fallbackName, requestedName) {
  const result = JSON.parse(toolResult.content[0].text);
  if (toolResult.isError || result.status !== "success") {
    throw new Error(`conversion failed: ${JSON.stringify(result)}`);
  }
  const resourceContent = toolResult.content.find((item) => item.type === "resource");
  if (!resourceContent?.resource?.blob) {
    throw new Error("conversion result did not include an output blob");
  }
  const outputBuffer = Buffer.from(resourceContent.resource.blob, "base64");
  const outputSha256 = sha256(outputBuffer);
  if (result.sha256 !== outputSha256) {
    throw new Error(`output sha256 mismatch: server=${result.sha256} client=${outputSha256}`);
  }
  if (existsSync(outputDir) && !statSync(outputDir).isDirectory()) {
    throw new Error(`output-dir is not a directory: ${outputDir}`);
  }
  mkdirSync(outputDir, { recursive: true });
  const outputName = requestedName
    ? outputFilename(result.output_filename, result.target, requestedName)
    : safeBasename(result.output_filename, fallbackName);
  const outputPath = resolve(outputDir, outputName);
  writeFileSync(outputPath, outputBuffer);
  return {
    result,
    outputPath,
    outputSha256,
    size: outputBuffer.length,
  };
}
