#!/usr/bin/env node
import { existsSync, readFileSync, statSync } from "node:fs";
import { basename, extname, isAbsolute, join, resolve } from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { outputFilename, saveRemoteResult } from "./hwp2020_mcp_client_result.mjs";
import { normalizePdfPageSetup } from "./hwp2020_mcp_page_setup.mjs";
import {
  defaultTimeoutSeconds,
  normalizeTimeoutSeconds,
  timeoutSecondsMaximum,
  timeoutSecondsMinimum,
} from "./hwp2020_mcp_timeout.mjs";

const defaultServerUrl = "";
const commandNames = new Set(["convert", "start", "status", "download"]);

function usage() {
  return [
    "Usage:",
    "  hwp2020-mcp-convert convert --env-file .env.local --input INPUT.hwp --target pdf --output-dir OUT_DIR",
    "  hwp2020-mcp-convert start --env-file .env.local --input INPUT.hwp --target pdf",
    "  hwp2020-mcp-convert status --env-file .env.local --job-id JOB_ID",
    "  hwp2020-mcp-convert download --env-file .env.local --job-id JOB_ID --output-dir OUT_DIR",
    "",
    "Commands:",
    "  convert                    Synchronous conversion. This is the legacy default when no command is supplied.",
    "  start                      Upload a local document and return an asynchronous conversion job ID.",
    "  status                     Query an asynchronous job state, phase, elapsed time, output bytes, and delivery state.",
    "  download                   Save a completed job result to a local directory after SHA-256 verification.",
    "",
    "Options:",
    "  --env-file PATH           Optional .env file with HWP2020_MCP_SERVER_URL and HWP2020_MCP_AUTH_TOKEN",
    "  --server-url URL          Remote Streamable HTTP MCP endpoint, default HWP2020_MCP_SERVER_URL",
    "  --auth-token TOKEN        Required bearer token, default HWP2020_MCP_AUTH_TOKEN",
    "  --input PATH              Local HWP/HWPX path read by start or convert",
    "  --target pdf|hwpx|hwp     Conversion target for start or convert",
    "  --job-id UUID             Job ID returned by start; required for status or download",
    "  --output-dir DIR          Local directory where convert or download saves the converted file",
    "  --output-filename NAME    Optional output filename for convert/start, or local name override for download",
    `  --timeout-seconds N       Conversion and MCP request timeout, default ${defaultTimeoutSeconds}, range ${timeoutSecondsMinimum}..${timeoutSecondsMaximum}`,
    "  --password-stdin          Read input HWP3/HWP5 .hwp or ODF-encrypted .hwpx password from standard input",
    "  --output-password-stdin   Read result HWP/HWPX password from standard input; PDF is rejected",
    "  --paper-size NAME         PDF only: a3 | a4 | a5 | b4 | letter | legal",
    "  --orientation NAME        PDF only: portrait | landscape",
    "",
    "npx examples:",
    "  printf '%s\\n' 'result-password' | npx -y --package=file:/path/to/hwp-convert-mcp-client.tar.gz -- hwp2020-mcp-convert start --env-file /path/to/.env.local --input sample.hwp --target hwpx --output-password-stdin",
    "  npx -y --package=file:/path/to/hwp-convert-mcp-client.tar.gz -- hwp2020-mcp-convert status --env-file /path/to/.env.local --job-id JOB_ID",
    "  npx -y --package=file:/path/to/hwp-convert-mcp-client.tar.gz -- hwp2020-mcp-convert download --env-file /path/to/.env.local --job-id JOB_ID --output-dir ./out",
  ].join("\n");
}

function parseArgs(argv) {
  const values = [...argv];
  const options = {
    command: "convert",
    timeoutSeconds: defaultTimeoutSeconds,
  };
  if (commandNames.has(values[0])) {
    options.command = values.shift();
  }
  for (let index = 0; index < values.length; index += 1) {
    const arg = values[index];
    const next = () => {
      index += 1;
      if (index >= values.length) {
        throw new Error(`missing value for ${arg}`);
      }
      return values[index];
    };
    if (arg === "--help" || arg === "-h") {
      options.help = true;
    } else if (arg === "--input") {
      options.input = next();
    } else if (arg === "--target") {
      options.target = next();
    } else if (arg === "--job-id") {
      options.jobId = next();
    } else if (arg === "--output-dir") {
      options.outputDir = next();
    } else if (arg === "--output-filename") {
      options.outputFilename = next();
    } else if (arg === "--timeout-seconds") {
      options.timeoutSeconds = Number.parseInt(next(), 10);
    } else if (arg === "--password-stdin") {
      options.passwordStdin = true;
    } else if (arg === "--output-password-stdin") {
      options.outputPasswordStdin = true;
    } else if (arg === "--paper-size") {
      options.paperSize = next();
    } else if (arg === "--orientation") {
      options.orientation = next();
    } else if (arg === "--server-url") {
      options.serverUrl = next();
    } else if (arg === "--auth-token") {
      options.authToken = next();
    } else if (arg === "--env-file") {
      options.envFile = next();
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  return options;
}

function readPasswordsFromStdin(options) {
  const lines = readFileSync(0, "utf8").split(/\r?\n/);
  let index = 0;
  if (options.passwordStdin) {
    options.password = lines[index++] ?? "";
  }
  if (options.outputPasswordStdin) {
    options.outputPassword = lines[index++] ?? "";
  }
}

function localPath(pathValue) {
  const value = String(pathValue || "").trim();
  if (!value) {
    throw new Error("path value must not be empty");
  }
  return resolve(isAbsolute(value) ? value : join(process.cwd(), value));
}

function parseEnvFile(filePath) {
  const envPath = localPath(filePath);
  if (!existsSync(envPath) || !statSync(envPath).isFile()) {
    throw new Error(`env file does not exist: ${envPath}`);
  }
  const result = {};
  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }
    const equalsAt = trimmed.indexOf("=");
    if (equalsAt < 1) {
      continue;
    }
    const key = trimmed.slice(0, equalsAt).trim();
    let value = trimmed.slice(equalsAt + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    result[key] = value;
  }
  return result;
}

function applyEnvironmentDefaults(options) {
  const fileEnv = options.envFile ? parseEnvFile(options.envFile) : {};
  options.serverUrl ||= fileEnv.HWP2020_MCP_SERVER_URL || process.env.HWP2020_MCP_SERVER_URL || defaultServerUrl;
  options.authToken ||= fileEnv.HWP2020_MCP_AUTH_TOKEN || process.env.HWP2020_MCP_AUTH_TOKEN || "";
  return options;
}

function normalizeTarget(value) {
  const target = String(value || "").toLowerCase();
  if (!['pdf', 'hwpx', 'hwp'].includes(target)) {
    throw new Error("target must be one of: pdf, hwpx, hwp");
  }
  return target;
}

function validateDirection(inputPath, target) {
  const inputExtension = extname(inputPath).toLowerCase();
  if (!['.hwp', '.hwpx'].includes(inputExtension)) {
    throw new Error("--input must end in .hwp or .hwpx");
  }
  const allowedTargets = inputExtension === ".hwp" ? new Set(["pdf", "hwpx", "hwp"]) : new Set(["pdf", "hwp"]);
  if (!allowedTargets.has(target)) {
    throw new Error(`unsupported target '${target}' for ${inputExtension}`);
  }
}

function validateJobId(value) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ""))) {
    throw new Error("--job-id must be a UUID returned by start");
  }
}

function validateOptions(options) {
  if (options.help) {
    return;
  }
  if (!options.serverUrl) {
    if (options.envFile) {
      throw new Error(`--server-url is required; set HWP2020_MCP_SERVER_URL in ${options.envFile} or pass --server-url`);
    }
    throw new Error("--server-url is required");
  }
  if (!options.authToken) {
    throw new Error("--auth-token is required");
  }
  options.timeoutSeconds = normalizeTimeoutSeconds(options.timeoutSeconds, { name: "--timeout-seconds" });
  if (options.command === "status" || options.command === "download") {
    validateJobId(options.jobId);
    if (options.command === "download" && !options.outputDir) {
      throw new Error("--output-dir is required for download");
    }
    return;
  }
  if (!options.input) {
    throw new Error("--input is required");
  }
  if (!options.target) {
    throw new Error("--target is required");
  }
  if (options.command === "convert" && !options.outputDir) {
    throw new Error("--output-dir is required for convert");
  }
  if (options.passwordStdin && !["convert", "start"].includes(options.command)) {
    throw new Error("--password-stdin is supported only for convert or start");
  }
  if (options.outputPasswordStdin && !["convert", "start"].includes(options.command)) {
    throw new Error("--output-password-stdin is supported only for convert or start");
  }
  if (options.outputPasswordStdin && normalizeTarget(options.target) === "pdf") {
    throw new Error("--output-password-stdin is supported only for hwp or hwpx target");
  }
  normalizePdfPageSetup(normalizeTarget(options.target), {
    paper_size: options.paperSize,
    orientation: options.orientation,
  });
}

function requestTimeoutMs(timeoutSeconds) {
  return (timeoutSeconds + 120) * 1000;
}

function createTransport(options) {
  return new StreamableHTTPClientTransport(new URL(options.serverUrl), {
    requestInit: { headers: { Authorization: `Bearer ${options.authToken}` } },
  });
}

async function withRemoteClient(options, operation) {
  const client = new Client({ name: "hwp2020-mcp-client-convert", version: "0" }, { capabilities: {} });
  await client.connect(createTransport(options));
  try {
    return await operation(client);
  } finally {
    await client.close();
  }
}

async function callTool(client, options, name, args) {
  return client.callTool({ name, arguments: args }, undefined, { timeout: requestTimeoutMs(options.timeoutSeconds) });
}

function parseToolText(toolResult) {
  const text = toolResult.content.find((item) => item.type === "text")?.text;
  if (!text) {
    throw new Error("remote MCP tool did not return JSON text content");
  }
  return JSON.parse(text);
}

function conversionRequest(options) {
  const inputPath = localPath(options.input);
  const target = normalizeTarget(options.target);
  if (!existsSync(inputPath) || !statSync(inputPath).isFile()) {
    throw new Error(`input does not exist: ${inputPath}`);
  }
  validateDirection(inputPath, target);
  const pageSetup = normalizePdfPageSetup(target, {
    paper_size: options.paperSize,
    orientation: options.orientation,
  });
  const requestedOutputName = outputFilename(inputPath, target, options.outputFilename);
  const remoteArguments = {
    input_filename: basename(inputPath),
    input_blob: readFileSync(inputPath).toString("base64"),
    target,
    output_filename: requestedOutputName,
    options: {
      timeout_seconds: options.timeoutSeconds,
      disable_pdf_hwpx_fallback: true,
      allow_sibling_fallbacks: false,
      paper_size: pageSetup?.paperSize,
      orientation: pageSetup?.orientation,
    },
  };
  if (options.password !== undefined) {
    remoteArguments.password = options.password;
  }
  if (options.outputPassword !== undefined) {
    remoteArguments.output_password = options.outputPassword;
  }
  return { inputPath, target, requestedOutputName, remoteArguments };
}

async function convert(options) {
  const request = conversionRequest(options);
  const outputDir = localPath(options.outputDir);
  return withRemoteClient(options, async (client) => {
    const toolResult = await callTool(client, options, "convert_document", request.remoteArguments);
    const saved = saveRemoteResult(toolResult, outputDir, request.requestedOutputName, options.outputFilename);
    return {
      status: "success",
      input_path: request.inputPath,
      output_path: saved.outputPath,
      target: request.target,
      output_filename: basename(saved.outputPath),
      size: saved.size,
      sha256: saved.outputSha256,
      conversion: saved.result.conversion,
      server: {
        job_id: saved.result.job_id,
        run_status: saved.result.run_status,
        validation: saved.result.validation,
      },
    };
  });
}

async function start(options) {
  const request = conversionRequest(options);
  return withRemoteClient(options, async (client) => {
    const toolResult = await callTool(client, options, "start_conversion", request.remoteArguments);
    const result = parseToolText(toolResult);
    if (toolResult.isError) {
      throw new Error(`conversion start failed: ${JSON.stringify(result)}`);
    }
    return result;
  });
}

async function status(options) {
  return withRemoteClient(options, async (client) => {
    const toolResult = await callTool(client, options, "get_conversion_status", { job_id: options.jobId });
    const result = parseToolText(toolResult);
    if (toolResult.isError) {
      throw new Error(`conversion status failed: ${JSON.stringify(result)}`);
    }
    return result;
  });
}

async function download(options) {
  const outputDir = localPath(options.outputDir);
  return withRemoteClient(options, async (client) => {
    const toolResult = await callTool(client, options, "get_conversion_result", { job_id: options.jobId });
    const saved = saveRemoteResult(toolResult, outputDir, "converted-output", options.outputFilename);
    return {
      status: "success",
      job_id: saved.result.job_id,
      output_path: saved.outputPath,
      output_filename: basename(saved.outputPath),
      size: saved.size,
      sha256: saved.outputSha256,
      conversion: saved.result.conversion,
      server: {
        run_status: saved.result.run_status,
        validation: saved.result.validation,
      },
    };
  });
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return 0;
  }
  applyEnvironmentDefaults(options);
  if (options.passwordStdin || options.outputPasswordStdin) {
    readPasswordsFromStdin(options);
  }
  validateOptions(options);
  const handlers = { convert, start, status, download };
  const result = await handlers[options.command](options);
  console.log(JSON.stringify(result, null, 2));
  return 0;
}

main()
  .then((code) => {
    process.exitCode = code;
  })
  .catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
