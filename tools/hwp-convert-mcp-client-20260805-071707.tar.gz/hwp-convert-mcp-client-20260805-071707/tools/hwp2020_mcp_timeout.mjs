export const defaultTimeoutSeconds = 900;
export const timeoutSecondsMinimum = 10;
export const timeoutSecondsMaximum = 3600;

export function normalizeTimeoutSeconds(value, { fallback = defaultTimeoutSeconds, name = "timeout_seconds" } = {}) {
  const timeoutSeconds = value ?? fallback;
  if (!Number.isInteger(timeoutSeconds)
      || timeoutSeconds < timeoutSecondsMinimum
      || timeoutSeconds > timeoutSecondsMaximum) {
    throw new Error(`${name} must be an integer between ${timeoutSecondsMinimum} and ${timeoutSecondsMaximum}`);
  }
  return timeoutSeconds;
}
