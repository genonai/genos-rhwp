#!/usr/bin/env node
import { existsSync, readFileSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { basename, extname, isAbsolute, join, resolve } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import * as z from "zod/v4";
import { outputFilename, saveRemoteResult } from "./hwp2020_mcp_client_result.mjs";
import { normalizePdfPageSetup, orientationNames, paperSizeNames } from "./hwp2020_mcp_page_setup.mjs";
import {
  defaultTimeoutSeconds,
  normalizeTimeoutSeconds,
  timeoutSecondsMaximum,
  timeoutSecondsMinimum,
} from "./hwp2020_mcp_timeout.mjs";

const defaultServerUrl = "";
const allowedCliArgs = new Set(["--server-url", "--auth-token", "--help", "-h"]);
const conversionToolArgs = new Set([
  "input_path",
  "target",
  "output_filename",
  "password",
  "output_password",
  "timeout_seconds",
  "clear_distribution",
  "table_patch_last_row_count",
  "disable_pdf_hwpx_fallback",
  "allow_sibling_fallbacks",
  "paper_size",
  "orientation",
]);
const synchronousToolArgs = new Set([...conversionToolArgs, "output_dir"]);
const statusToolArgs = new Set(["job_id", "timeout_seconds"]);
const saveToolArgs = new Set(["job_id", "output_dir", "output_filename", "timeout_seconds"]);

const conversionSchemaShape = {
  input_path: z.string().describe("Local .hwp or .hwpx path on the MCP client machine."),
  target: z.enum(["pdf", "hwpx", "hwp"]).describe("Conversion target."),
  output_filename: z.string().optional().describe("Optional output basename. Extension is appended if missing."),
  password: z.string().max(4096).optional().describe("Optional password for encrypted .hwp or .hwpx input. It is sent only to the remote conversion request."),
  output_password: z.string().min(1).max(4096).optional().describe("Optional password for the resulting hwp or hwpx file. PDF target does not support it."),
  timeout_seconds: z.number().int().min(timeoutSecondsMinimum).max(timeoutSecondsMaximum).optional().describe("Remote conversion timeout in seconds. Also extends the MCP request wait. Default is 900."),
  clear_distribution: z.boolean().optional().describe("Request retry with HWP distribution flag cleared. Default false; use only when document policy allows it."),
  table_patch_last_row_count: z.boolean().optional().describe("Patch a known HWP table last-row-count metadata issue before conversion. Default false."),
  disable_pdf_hwpx_fallback: z.boolean().optional().describe("Disable PDF fallback through HWPX. Default true for predictable direct PDF conversion."),
  allow_sibling_fallbacks: z.boolean().optional().describe("Allow server-side fallback to sibling files. Default false so only the requested input is converted."),
  paper_size: z.enum(paperSizeNames).optional().describe("PDF only paper size: a3, a4, a5, b4, letter, legal."),
  orientation: z.enum(orientationNames).optional().describe("PDF only orientation: portrait or landscape."),
};

function usage() {
  return [
    "Usage:",
    "  hwp2020-mcp-bridge [--server-url URL] [--auth-token TOKEN]",
    "",
    "This command starts a stdio MCP bridge. It does not convert a file by itself.",
    "Register it in VS Code or another MCP client, then call one of the MCP tools below.",
    "",
    "MCP tools:",
    "  convert_local_document           Legacy synchronous local conversion and save",
    "  start_local_document_conversion  Upload a local input and return an asynchronous job ID",
    "  get_local_conversion_status      Query a job state, phase, output bytes, and delivery state",
    "  save_local_conversion_result     Download a completed job and save it to a local directory",
    "",
    "Async lifecycle:",
    "  1. Call start_local_document_conversion and retain job_id.",
    "  2. Call get_local_conversion_status until status is succeeded or failed.",
    "  3. Call save_local_conversion_result with job_id and local output_dir.",
    "",
    "Timeout:",
    `  timeout_seconds is ${timeoutSecondsMinimum}..${timeoutSecondsMaximum} and defaults to ${defaultTimeoutSeconds}. Status is truthful phase/output byte monitoring;`,
    "  Hancom does not provide reliable page-by-page progress so progress_percent is null.",
    "",
    "Supported conversions:",
    "  hwp  -> pdf | hwpx | hwp",
    "  hwpx -> pdf | hwp",
    "",
    "Environment:",
    "  HWP2020_MCP_SERVER_URL    Remote Streamable HTTP MCP endpoint",
    "  HWP2020_MCP_AUTH_TOKEN    Required bearer token",
    "",
    "Recommended VS Code setup:",
    "  1. Put HWP2020_MCP_AUTH_TOKEN and HWP2020_MCP_SERVER_URL in .env.local.",
    "  2. Register this bridge in .vscode/mcp.json with envFile pointing to .env.local.",
    "  3. On macOS GUI launchers, use an absolute npx path and set env.PATH for node.",
    "",
    "VS Code npx example:",
    "  /opt/homebrew/bin/npx -y --package=file:$HOME/Cloud/Devel/hwp-convert/hwp-convert-mcp-client-YYYYMMDD-HHMMSS.tar.gz -- hwp2020-mcp-bridge",
    "",
    "Direct CLI async example:",
    "  npx -y --package=file:/path/to/hwp-convert-mcp-client-YYYYMMDD-HHMMSS.tar.gz -- hwp2020-mcp-convert start --env-file /path/to/.env.local --input /path/to/input.hwp --target pdf --timeout-seconds 900",
  ].join("\n");
}

function parseArgs(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (!allowedCliArgs.has(arg)) {
      throw new Error(`unknown argument: ${arg}`);
    }
    if (arg === "--help" || arg === "-h") {
      options.help = true;
      continue;
    }
    index += 1;
    if (index >= argv.length) {
      throw new Error(`missing value for ${arg}`);
    }
    if (arg === "--server-url") {
      options.serverUrl = argv[index];
    } else if (arg === "--auth-token") {
      options.authToken = argv[index];
    }
  }
  return options;
}

function bridgeConfig(cliOptions) {
  const serverUrl = String(cliOptions.serverUrl || process.env.HWP2020_MCP_SERVER_URL || defaultServerUrl).trim();
  const authToken = String(cliOptions.authToken || process.env.HWP2020_MCP_AUTH_TOKEN || "").trim();
  if (!serverUrl) {
    throw new Error("remote MCP server URL is required");
  }
  if (!authToken) {
    throw new Error("HWP2020_MCP_AUTH_TOKEN or --auth-token is required");
  }
  return { serverUrl, authToken };
}

function rejectUnknownKeys(value, allowedKeys, label) {
  const unknownKeys = Object.keys(value || {}).filter((key) => !allowedKeys.has(key));
  if (unknownKeys.length > 0) {
    throw new Error(`${label} contains unsupported key(s): ${unknownKeys.join(", ")}`);
  }
}

function validatePassword(value, label = "password", allowEmpty = true) {
  if (value === undefined) {
    return;
  }
  if (typeof value !== "string" || Buffer.byteLength(value, "utf8") > 4096) {
    throw new Error(`${label} must be a string no longer than 4096 UTF-8 bytes`);
  }
  if (/\r|\n/.test(value)) {
    throw new Error(`${label} must not contain a line break`);
  }
  if (!allowEmpty && value.length === 0) {
    throw new Error(`${label} must not be empty`);
  }
}

function expandHome(pathValue) {
  const value = String(pathValue || "").trim();
  if (value === "~") {
    return homedir();
  }
  if (value.startsWith("~/")) {
    return join(homedir(), value.slice(2));
  }
  return value;
}

function localPath(pathValue) {
  const expanded = expandHome(pathValue);
  if (!expanded) {
    throw new Error("path value must not be empty");
  }
  return resolve(isAbsolute(expanded) ? expanded : join(process.cwd(), expanded));
}

function normalizeTarget(value) {
  const target = String(value || "").toLowerCase();
  if (!["pdf", "hwpx", "hwp"].includes(target)) {
    throw new Error("target must be one of: pdf, hwpx, hwp");
  }
  return target;
}

function validateDirection(inputPath, target) {
  const inputExt = extname(inputPath).toLowerCase();
  const allowedTargets = inputExt === ".hwp" ? new Set(["pdf", "hwpx", "hwp"]) : new Set(["pdf", "hwp"]);
  if (![".hwp", ".hwpx"].includes(inputExt)) {
    throw new Error("input_path extension must be .hwp or .hwpx");
  }
  if (!allowedTargets.has(target)) {
    throw new Error(`unsupported target '${target}' for ${inputExt}`);
  }
}

function validateJobId(value) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ""))) {
    throw new Error("job_id must be a UUID returned by start_local_document_conversion");
  }
}

function normalizeTimeout(value) {
  return normalizeTimeoutSeconds(value);
}

function requestTimeoutMs(timeoutSeconds) {
  return (timeoutSeconds + 120) * 1000;
}

function optionBoolean(args, name, fallback) {
  const value = args[name] ?? fallback;
  if (typeof value !== "boolean") {
    throw new Error(`${name} must be boolean`);
  }
  return value;
}

function createTransport(config) {
  return new StreamableHTTPClientTransport(new URL(config.serverUrl), {
    requestInit: { headers: { Authorization: `Bearer ${config.authToken}` } },
  });
}

async function callRemoteTool(config, name, args, timeoutSeconds) {
  const client = new Client({ name: "hwp2020-mcp-stdio-bridge", version: "0.2.0" }, { capabilities: {} });
  await client.connect(createTransport(config));
  try {
    return await client.callTool({ name, arguments: args }, undefined, { timeout: requestTimeoutMs(timeoutSeconds) });
  } finally {
    await client.close();
  }
}

function parseToolText(remoteResult) {
  const text = remoteResult.content.find((item) => item.type === "text")?.text;
  if (!text) {
    throw new Error("remote MCP tool did not return JSON text content");
  }
  return JSON.parse(text);
}

function remoteConversionRequest(args) {
  validatePassword(args.password);
  validatePassword(args.output_password, "output_password", false);
  const inputPath = localPath(args.input_path);
  const target = normalizeTarget(args.target);
  validateDirection(inputPath, target);
  if (args.output_password !== undefined && target === "pdf") {
    throw new Error("output_password is supported only for hwp or hwpx target");
  }
  if (!existsSync(inputPath) || !statSync(inputPath).isFile()) {
    throw new Error(`input_path does not exist or is not a file: ${inputPath}`);
  }
  const pageSetup = normalizePdfPageSetup(target, args);
  const timeoutSeconds = normalizeTimeout(args.timeout_seconds);
  const requestedOutputName = outputFilename(inputPath, target, args.output_filename);
  const remoteArguments = {
    input_filename: basename(inputPath),
    input_blob: readFileSync(inputPath).toString("base64"),
    target,
    output_filename: requestedOutputName,
    options: {
      timeout_seconds: timeoutSeconds,
      clear_distribution: optionBoolean(args, "clear_distribution", false),
      table_patch_last_row_count: optionBoolean(args, "table_patch_last_row_count", false),
      disable_pdf_hwpx_fallback: optionBoolean(args, "disable_pdf_hwpx_fallback", true),
      allow_sibling_fallbacks: optionBoolean(args, "allow_sibling_fallbacks", false),
      paper_size: pageSetup?.paperSize,
      orientation: pageSetup?.orientation,
    },
  };
  if (args.password !== undefined) {
    remoteArguments.password = args.password;
  }
  if (args.output_password !== undefined) {
    remoteArguments.output_password = args.output_password;
  }
  return { inputPath, target, timeoutSeconds, requestedOutputName, remoteArguments };
}

async function convertLocalDocument(config, args) {
  rejectUnknownKeys(args, synchronousToolArgs, "tool arguments");
  const outputDir = localPath(args.output_dir);
  const request = remoteConversionRequest(args);
  const remoteResult = await callRemoteTool(config, "convert_document", request.remoteArguments, request.timeoutSeconds);
  const saved = saveRemoteResult(remoteResult, outputDir, request.requestedOutputName, args.output_filename);
  return {
    status: "success",
    input_path: request.inputPath,
    output_path: saved.outputPath,
    target: request.target,
    output_filename: basename(saved.outputPath),
    size: saved.size,
    sha256: saved.outputSha256,
    server: {
      job_id: saved.result.job_id,
      run_status: saved.result.run_status,
      validation: saved.result.validation,
      conversion: saved.result.conversion,
    },
  };
}

async function startLocalDocumentConversion(config, args) {
  rejectUnknownKeys(args, conversionToolArgs, "tool arguments");
  const request = remoteConversionRequest(args);
  const remoteResult = await callRemoteTool(config, "start_conversion", request.remoteArguments, request.timeoutSeconds);
  const result = parseToolText(remoteResult);
  if (remoteResult.isError) {
    throw new Error(`remote conversion start failed: ${JSON.stringify(result)}`);
  }
  return result;
}

async function getLocalConversionStatus(config, args) {
  rejectUnknownKeys(args, statusToolArgs, "tool arguments");
  validateJobId(args.job_id);
  const timeoutSeconds = normalizeTimeout(args.timeout_seconds);
  const remoteResult = await callRemoteTool(config, "get_conversion_status", { job_id: args.job_id }, timeoutSeconds);
  const result = parseToolText(remoteResult);
  if (remoteResult.isError) {
    throw new Error(`remote conversion status failed: ${JSON.stringify(result)}`);
  }
  return result;
}

async function saveLocalConversionResult(config, args) {
  rejectUnknownKeys(args, saveToolArgs, "tool arguments");
  validateJobId(args.job_id);
  const outputDir = localPath(args.output_dir);
  const timeoutSeconds = normalizeTimeout(args.timeout_seconds);
  const remoteResult = await callRemoteTool(config, "get_conversion_result", { job_id: args.job_id }, timeoutSeconds);
  const saved = saveRemoteResult(remoteResult, outputDir, "converted-output", args.output_filename);
  return {
    status: "success",
    job_id: saved.result.job_id,
    output_path: saved.outputPath,
    output_filename: basename(saved.outputPath),
    size: saved.size,
    sha256: saved.outputSha256,
    server: {
      run_status: saved.result.run_status,
      validation: saved.result.validation,
      conversion: saved.result.conversion,
    },
  };
}

function response(handler) {
  return async (args) => {
    try {
      return { content: [{ type: "text", text: JSON.stringify(await handler(args), null, 2) }], isError: false };
    } catch (error) {
      return { content: [{ type: "text", text: JSON.stringify({ status: "failed", error: error.message }, null, 2) }], isError: true };
    }
  };
}

function createBridgeServer(config) {
  const server = new McpServer({ name: "hwp2020-local-bridge", version: "0.2.0" });
  server.registerTool(
    "convert_local_document",
    {
      title: "Convert local HWP/HWPX document",
      description: "Read a local HWP/HWPX file, synchronously convert it through the remote Hancom Office 2020 MCP server, and save the result locally.",
      inputSchema: z.strictObject({ ...conversionSchemaShape, output_dir: z.string().describe("Local output directory on the MCP client machine.") }),
    },
    response((args) => convertLocalDocument(config, args)),
  );
  server.registerTool(
    "start_local_document_conversion",
    {
      title: "Start local HWP/HWPX conversion",
      description: "Upload a local HWP/HWPX file to the remote server and return a job ID for status polling.",
      inputSchema: z.strictObject(conversionSchemaShape),
    },
    response((args) => startLocalDocumentConversion(config, args)),
  );
  server.registerTool(
    "get_local_conversion_status",
    {
      title: "Get local conversion job status",
      description: "Get remote job phase, elapsed time, output bytes, and response delivery status without exposing server paths.",
      inputSchema: z.strictObject({ job_id: z.string().uuid(), timeout_seconds: z.number().int().min(timeoutSecondsMinimum).max(timeoutSecondsMaximum).optional() }),
    },
    response((args) => getLocalConversionStatus(config, args)),
  );
  server.registerTool(
    "save_local_conversion_result",
    {
      title: "Save completed conversion result locally",
      description: "Download a succeeded remote job, verify its SHA-256, and save it to a local client directory.",
      inputSchema: z.strictObject({
        job_id: z.string().uuid(),
        output_dir: z.string(),
        output_filename: z.string().optional(),
        timeout_seconds: z.number().int().min(timeoutSecondsMinimum).max(timeoutSecondsMaximum).optional(),
      }),
    },
    response((args) => saveLocalConversionResult(config, args)),
  );
  return server;
}

async function main() {
  const cliOptions = parseArgs(process.argv.slice(2));
  if (cliOptions.help) {
    console.log(usage());
    return;
  }
  const server = createBridgeServer(bridgeConfig(cliOptions));
  await server.connect(new StdioServerTransport());
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
